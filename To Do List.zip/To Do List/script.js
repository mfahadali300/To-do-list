let main = document.querySelector(".main");
let input = document.querySelector(".content");
let btn = document.querySelector(".add-task");
let tasks = document.querySelector(".tasks");
let error = document.querySelector(".error");
let updateError = document.querySelector(".update-error");
let h1 = document.querySelector("h1");
const heading = document.querySelector(".heading");
let dark = document.querySelector(".dark");
let light = document.querySelector(".light");

light.addEventListener("click", function(){
    main.style.backgroundColor = "white";
    btn.style.backgroundColor = "#414040";
    btn.style.color = "white";
    h1.style.color = "#414040"
    light.style.color = "white";
    light.style.backgroundColor = "#414040";
    dark.style.color = "black";
    dark.style.backgroundColor = "transparent";
})

let themeval = dark.addEventListener("click", function(){
    main.style.backgroundColor = "#1d1a1a";
    btn.style.backgroundColor = "white";
    btn.style.color = "black";
    light.style.color = "white";
    light.style.backgroundColor = "transparent";
    dark.style.color = "black";
    dark.style.backgroundColor = "white";
    h1.style.color = "white";
})



const text = heading.textContent;
heading.innerHTML = [...text].map((char, i) => {
    if (char === " ") {
      return `<span style="width: 10px; display: inline-block;">&nbsp;</span>`;
    }
    return `<span style="display:inline-block; animation-delay: ${i * 0.05}s">${char}</span>`;
  }).join('');

window.addEventListener("load", loadStorage)
window.addEventListener("keypress", (e) => {
    if (e.key === 'Enter') {
        addTask();
    }
})
btn.addEventListener("click", addTask)

function addTask() {
    let taskText = input.value.trim();
    if (taskText !== "") {
        let task = {
            text: taskText,
            completed: false,
        }
        saveTOStorage(task);
        showTask(task);
        input.value = "";
        error.style.display = "none";
        updateError.style.display = "none";
    } else {
        error.style.display = "initial";
        updateError.style.display = "none";
    }
}

function loadStorage() {
    let allTasks = JSON.parse(localStorage.getItem("tasks")) || [];
    allTasks.forEach(task => {
        showTask(task)
    });
}

function showTask(task) {
    let li = document.createElement("li")
    li.classList.add("task-list")
    li.innerHTML = `
                    <span class="${task.completed ? 'completed' : ''}">${task.text}</span>
                    <div>
                        <button class="complete buttons"><i class="fa-solid fa-circle-check"></i></button>
                        <button class="update buttons"><i class="fa-solid fa-pen-to-square"></i></button>
                        <button class="delete buttons"><i class="fa-solid fa-trash"></i></button>
                    </div>`

    tasks.appendChild(li);
}

function saveTOStorage(task) {
    let allTasks = JSON.parse(localStorage.getItem("tasks")) || [];
    allTasks.push(task);
    localStorage.setItem("tasks", JSON.stringify(allTasks));

}

function updateStorage() {
    let allLi = document.querySelectorAll(".task-list");
    let updatedTasks = [];

    allLi.forEach(li => {
        let text = li.querySelector("span").textContent;
        let completed = li.querySelector("span").classList.contains("completed");
        updatedTasks.push({ text, completed })
    })
    localStorage.setItem("tasks", JSON.stringify(updatedTasks));
}


tasks.addEventListener("click", (e) => {
    if (e.target.closest(".delete")) {
        e.target.closest("li").remove()
        updateStorage();
        error.style.display = "none";
        updateError.style.display = "none";
    }

    if (e.target.closest(".complete")) {
        let lineThrough = e.target.closest("li").querySelector("span");
        lineThrough.classList.add("completed")
        updateStorage();
        error.style.display = "none";
        updateError.style.display = "none"
    }


    if (e.target.closest(".update")) {
        let updatedTask = e.target.closest("li").querySelector("span");
        if (updatedTask.className !== "completed") {
            let newVal = prompt("Enter updated task");
            if (newVal !== "" && newVal !== null) {
                updatedTask.textContent = newVal;
                updateStorage();
                updateError.style.display = "none"
            }
        } else {
            updateError.style.display = "initial"
            error.style.display = "none";
        }
    }
})

